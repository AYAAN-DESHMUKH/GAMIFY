package com.example.practise;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class signup_page extends AppCompatActivity {
    Button sign;
    EditText first,last,contact,pass,confirm;
    String f,l,c,p,c1;
    EditText email,password;
    FirebaseAuth auth;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_page);
        auth= FirebaseAuth.getInstance();
        first=findViewById(R.id.first1);
        sign=findViewById(R.id.signin);
        last=findViewById(R.id.last1);
        contact=findViewById(R.id.contact1);
        pass=findViewById(R.id.pass1);
        confirm=findViewById(R.id.confirm1);
        f=first.getText().toString();
        l=last.getText().toString();
        c=contact.getText().toString();
        p=pass.getText().toString();
        c1=confirm.getText().toString();
        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                createuser();
            }
        });




    }

    private void createuser() {
        String emailid=contact.getText().toString();
        String password=pass.getText().toString();
        auth.createUserWithEmailAndPassword(emailid,password).addOnCompleteListener(signup_page.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {Toast.makeText(signup_page.this,"signup successfull",Toast.LENGTH_LONG).show();
                    Intent intent=new Intent(signup_page.this, login.class);
                    startActivity(intent);

                }

            }

        });
    }
}