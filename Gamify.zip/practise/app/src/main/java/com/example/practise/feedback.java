package com.example.practise;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class feedback extends AppCompatActivity {
EditText name,message;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        name=findViewById(R.id.name_feedback);
        message=findViewById(R.id.feed_message);
        submit=findViewById(R.id.feed_submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                start();
            }

            private void start() {
                HashMap<String,Object> map=new     HashMap<String,Object>();
                map.put("names",name.getText().toString());
                map.put("feedback",message.getText().toString());
                FirebaseDatabase.getInstance().getReference().child("feedback data").push().setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(getApplicationContext(),"feedback submitted",Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }
}