package com.example.practise;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;

public class godofwarragnarok extends AppCompatActivity {

    ImageView imagetesting;
    Button more;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_godofwarragnarok);
       more=findViewById(R.id.more);

        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(godofwarragnarok.this,testing.class));
            }
        });
    }

    private void image(){
    new Thread(()->{
        try
        {
            String url="https://www.rockpapershotgun.com/games/god-of-war-ragnarok";
            Document doc = Jsoup.connect(url).get();
            Elements images = doc.select("div.page_content");
            if (!images.isEmpty()) {
                int size=images.size();
                for(int i=0;i<size;i++)
                {
                    String imageUrl = images.select("div.cover_image_wrapper").select("img").attr("abs:src");//more good extraction
                    // Load the image using Picasso
                    runOnUiThread(() -> {
                        Picasso.get().load(imageUrl).into(imagetesting);
                    });
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }).start();
    }
}












