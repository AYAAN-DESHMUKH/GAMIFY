package com.example.practise;

public abstract class FetchDataTask {
    protected abstract String doInBackground(Void... voids);

    protected abstract void onPostExecute(String result);
}
