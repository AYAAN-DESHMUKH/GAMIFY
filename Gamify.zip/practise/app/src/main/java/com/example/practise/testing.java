package com.example.practise;


import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.appcompat.app.AppCompatActivity;


import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
public class testing extends AppCompatActivity {

    static TextView textViewResult,ratings,developers,release_date,genre;
    static EditText search;
    TextView platform,releasedate,develop,generation,ingametext;
    ImageView picture;
    ImageView image1, image2, image3, image4, image5;
    Button searchbutton;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testing);
        genre=findViewById(R.id.textView5);
        search=findViewById(R.id.gametext);
ingametext=findViewById(R.id.ingametext);
        platform=findViewById(R.id.platforms);
        releasedate=findViewById(R.id.releasedate);
        develop=findViewById(R.id.developers);
        generation=findViewById(R.id.genres);
        //invisivle{
        platform.setVisibility(View.INVISIBLE);
        releasedate.setVisibility(View.INVISIBLE);
        develop.setVisibility(View.INVISIBLE);
        generation.setVisibility(View.INVISIBLE);
        ingametext.setVisibility(View.INVISIBLE);
        //}
ratings=findViewById(R.id.textView2);
developers=findViewById(R.id.textView4);
        release_date=findViewById(R.id.textView3);
        searchbutton=findViewById(R.id.gamesearch);
        picture=findViewById(R.id.gamepic);
image1=findViewById(R.id.igimage1);
        image2=findViewById(R.id.igimage2);
        image3=findViewById(R.id.igimage3);
        image4=findViewById(R.id.igimage4);
        image5=findViewById(R.id.igimage5);


        textViewResult = findViewById(R.id.textView);

        searchbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                imagegeneration();
   igimage2();
                igimage3();
                igimage4();
                igimage5();
                new boombim().execute();
                new rating().execute();
                new develop().execute();
                new releasedate().execute();
    new genre().execute();
    igimage1();
                platform.setVisibility(View.VISIBLE);
                releasedate.setVisibility(View.VISIBLE);
                develop.setVisibility(View.VISIBLE);
                generation.setVisibility(View.VISIBLE);
                ingametext.setVisibility(View.VISIBLE);

            }




            void imagegeneration() {
                new Thread(() -> {
                    try {
String a=search.getText().toString().replace(' ','-');
                        String targetUrl = "https://www.rockpapershotgun.com/games/"+a; // Replace with the URL of the webpage to scrape
                        Document doc = Jsoup.connect(targetUrl).get();
                        Elements images = doc.select("div.page_content");
                        if (!images.isEmpty()) {
                            int size=images.size();
                            for(int i=0;i<size;i++)
                            {
                                String imageUrl = images.select("div.cover_image_wrapper").select("img").attr("abs:src");//more good extraction
                                // Load the image using Picasso
                                runOnUiThread(() -> {
                                    Picasso.get().load(imageUrl).into(picture);
                                });
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }).start();
            }




        });








    }



    class boombim extends AsyncTask<Void, Void, String> {




        @Override
        protected String doInBackground(Void... voids) {
            try {
                String a=search.getText().toString().replace(' ','-');
                Document document = Jsoup.connect("https://www.rockpapershotgun.com/games/" + a ).get();
                Elements paragraphs = document.select("div.details"); // Select all <p> elements on the page

                int size=paragraphs.size();
                for(int i=0;i<size;i++) {
                    String text=paragraphs.select("p").eq(i).text();
                    return text;
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {

                textViewResult.setText(result);
            } else {
                textViewResult.setText("failed to show the information,try using '-' in case of spaces");
            }
        }
    }

    class genre extends AsyncTask<Void, Void, String> {




        @Override
        protected String doInBackground(Void... voids) {
            try {

                String a=search.getText().toString().replace(' ','-');

                Document document = Jsoup.connect("https://www.rockpapershotgun.com/games/" + a ).get();
                Elements paragraphs = document.select("div.tag_metadata"); // Select all <p> elements on the page



                String text = paragraphs.select("div.item").select("ul").eq(2).text();



                return text;


            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {

                genre.setText(result);
            } else {
               genre.setText("failed to show the information,try using '-' in case of spaces");
            }
        }
    }
class releasedate extends AsyncTask<Void, Void, String> {




    @Override
    protected String doInBackground(Void... voids) {
        try {

            String a=search.getText().toString().replace(' ','-');

            Document document = Jsoup.connect("https://www.rockpapershotgun.com/games/" + a ).get();
            Elements paragraphs = document.select("div.tag_metadata"); // Select all <p> elements on the page



            String text = paragraphs.select("div.item").select("span").eq(2).text();



            return text;


        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String result) {
        if (result != null) {

            release_date.setText(result);
        } else {
            release_date.setText("failed to show the information,try using '-' in case of spaces");
        }
    }
}


    private class rating  extends AsyncTask<Void, Void, String> {




        @Override
        protected String doInBackground(Void... voids) {
            try {

                String a=search.getText().toString().replace(' ','-');

                Document document = Jsoup.connect("https://www.rockpapershotgun.com/games/" + a ).get();
                Elements paragraphs = document.select("div.tag_metadata"); // Select all <p> elements on the page



                    String text = paragraphs.select("div.item").select("ul").eq(0).text();



                return text;


            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {

                ratings.setText(result);
            } else {
                ratings.setText("failed to show the information,try using '-' in case of spaces");
            }
        }
    }


class develop extends AsyncTask<Void, Void, String> {




    @Override
    protected String doInBackground(Void... voids) {
        try {

            String a=search.getText().toString().replace(' ','-');

            Document document = Jsoup.connect("https://www.rockpapershotgun.com/games/" + a ).get();
            Elements paragraphs = document.select("div.tag_metadata"); // Select all <p> elements on the page



            String text = paragraphs.select("div.item").select("ul").eq(1).text();



            return text;


        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String result) {
        if (result != null) {

          developers.setText(result);
        } else {
            developers.setText("failed to show the information,try using '-' in case of spaces");
        }
    }
}

void igimage1()
{

    new Thread(() -> {
        try {

            String a=search.getText().toString().replace(' ','-');
            String targetUrl = "https://www.trueachievements.com/game/"+a+"/screenshots";// Replace with the URL of the webpage to scrape
            Document doc = Jsoup.connect(targetUrl).get();
            Elements images = doc.select("div.screens");
            if (!images.isEmpty()) {



                    String imageUrl = images.select("img").eq(0).attr("abs:src");//more good extraction
                    // Load the image using Picasso
                    runOnUiThread(() -> {
                        Picasso.get().load(imageUrl).into(image1);
                    });

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }).start();
}
    void igimage2()
    {

        new Thread(() -> {
            try {
                String a=search.getText().toString().replace(' ','-');
                String targetUrl = "https://www.trueachievements.com/game/"+a+"/screenshots";// Replace with the URL of the webpage to scrape
                Document doc = Jsoup.connect(targetUrl).get();
                Elements images = doc.select("div.screens");
                if (!images.isEmpty()) {

                    String imageUrl = images.select("img").eq(1).attr("abs:src");//more good extraction
                    // Load the image using Picasso
                    runOnUiThread(() -> {
                        Picasso.get().load(imageUrl).into(image2);
                    });

                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }
    void igimage3()
    {

        new Thread(() -> {
            try {
                String a=search.getText().toString().replace(' ','-');
                String targetUrl = "https://www.trueachievements.com/game/"+a+"/screenshots"; // Replace with the URL of the webpage to scrape
                Document doc = Jsoup.connect(targetUrl).get();
                Elements images = doc.select("div.screens");
                if (!images.isEmpty()) {

                    String imageUrl = images.select("img").eq(2).attr("abs:src");//more good extraction
                    // Load the image using Picasso
                    runOnUiThread(() -> {
                        Picasso.get().load(imageUrl).into(image3);
                    });

                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }
    void igimage4()
    {

        new Thread(() -> {
            try {
                String a=search.getText().toString().replace(' ','-');
                String targetUrl = "https://www.trueachievements.com/game/"+a+"/screenshots"; // Replace with the URL of the webpage to scrape
                Document doc = Jsoup.connect(targetUrl).get();
                Elements images = doc.select("div.screens");
                if (!images.isEmpty()) {

                    String imageUrl = images.select("img").eq(3).attr("abs:src");//more good extraction
                    // Load the image using Picasso
                    runOnUiThread(() -> {
                        Picasso.get().load(imageUrl).into(image4);
                    });

                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }
    void igimage5()
    {

        new Thread(() -> {
            try {
                String a=search.getText().toString().replace(' ','-');
                String targetUrl = "https://www.trueachievements.com/game/"+a+"/screenshots"; // Replace with the URL of the webpage to scrape
                Document doc = Jsoup.connect(targetUrl).get();
                Elements images = doc.select("div.screens");
                if (!images.isEmpty()) {

                    String imageUrl = images.select("img").eq(4).attr("abs:src");//more good extraction

                    // Load the image using Picasso
                    runOnUiThread(() -> {
                        Picasso.get().load(imageUrl).into(image5);


                    });

                }



            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }
}

