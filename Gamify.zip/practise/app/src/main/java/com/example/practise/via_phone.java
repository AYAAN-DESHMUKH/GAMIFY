package com.example.practise;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.io.IOException;

public class via_phone extends AppCompatActivity {

    ImageView image,image2,image3;
    TextView textViewResult,textviewResult2,textviewResult3;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_via_phone);
        image = findViewById(R.id.imagetesting);
        textViewResult = findViewById(R.id.textnews);
        textviewResult2=findViewById(R.id.textnews2);
        image2=findViewById(R.id.imagetesting2);
        image3=findViewById(R.id.imagetesting3);
        textviewResult3=findViewById(R.id.textnews3);
        textViewResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String link="https://www.pcgamer.com/news/";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(link));
                startActivity(intent);

            }
        });
    image2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String link="https://www.oneesports.gg/";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(link));
                startActivity(intent);

            }
        });
        image3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String link="https://www.indiatodaygaming.com/news/";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(link));
                startActivity(intent);

            }
        });
        textviewResult2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String link="https://www.oneesports.gg/";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(link));
                startActivity(intent);

            }
        });
        textviewResult3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String link="https://www.indiatodaygaming.com/news/";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(link));
                startActivity(intent);

            }
        });

        new superman().execute();
        lastimage();
        imageexecute();
        imagegeneration();
new batman().execute();
        new spiderman().execute();
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = "https://www.pcgamer.com/news/"; // Replace this with your desired URL
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });
             // Replace this with your desired URL


    }


    class spiderman extends AsyncTask<Void, Void, String> {
       @Override
       protected String doInBackground(Void... voids) {
           try {

               Document document = Jsoup.connect("https://www.indiatodaygaming.com/news/").get();
  Elements search= document.select("div.pl-item");
  int size=search.size();


  for(int i=0;i<size;i++)
  {
      String text=search.select("div.pl-des").select("h3").eq(i).text();
  return text;

  }

}


        catch (IOException e) {
               e.printStackTrace();
           }
           return null;
       }

       @Override
       protected void onPostExecute(String result) {
           if (result != null) {

               textviewResult3.setText(result);
           } else {

              textviewResult3.setText("failed to show the information,try using '-' in case of spaces");
           }
       }
   }



    class superman extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            try {

                Document document = Jsoup.connect("https://www.pcgamer.com/news/").get();
                Elements search= document.select("figure.feature-block-item");
                int size=search.size();


                for(int i=0;i<size;i++)
                {
                    String text=search.select("span.article-name").eq(i).text();
                    return text;

                }

            }


            catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {

                textViewResult.setText(result);
            } else {

                textViewResult.setText("failed to show the information,try using '-' in case of spaces");
            }
        }
    }















    class batman extends AsyncTask<Void, Void, String>
   {

       @Override
       protected String doInBackground(Void... voids) {
           try {

               Document document = Jsoup.connect("https://www.oneesports.gg/").get();
               Elements search= document.select("div.content-wrapper");
               int size=search.size();


               for(int i=0;i<size;i++)
               {
                   String text=search.select("div.content").select("h2").eq(i).text();
                   return text;

               }

           }


           catch (IOException e) {
               e.printStackTrace();//methods calls tracing(checks error)
           }
           return null;
       }

       @Override
       protected void onPostExecute(String result) {
           if (result != null) {
               textviewResult2.setText(result);

           } else {
               textviewResult2.setText("cant show news today");

           }
       }


   }





private void lastimage()
{

    new Thread(() -> {

        try {
            Document doc = Jsoup.connect("https://www.indiatodaygaming.com/news/").get();
            Elements img = doc.select("div.pl-item");//changes if failure
            if (!img.isEmpty()) {
                int size=img.size();
                for(int i=0;i<size;i++){

                    String imageurl = img.select("div.pl-thumb").select("img").attr("abs:src");
                    runOnUiThread(() -> {

                        Picasso.get().load(imageurl).into(image3);
                    });
                }


            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }).start();

}










    private void imageexecute() {
        new Thread(() -> {

            try {
                Document doc = Jsoup.connect("https://www.pcgamer.com/news/").get();
                Elements img = doc.select("figure.feature-block-item");//changes if failure
                if (!img.isEmpty()) {
                    int size=img.size();
                    for(int i=0;i<size;i++){

                        String imageurl = img.select("div.image-remove-reflow-container").select("img").attr("abs:src");
                        runOnUiThread(() -> {

                            Picasso.get().load(imageurl).into(image);
                        });
                    }


                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }).start();
    }


private void imagegeneration(){



    new Thread(() -> {

        try {
            Document doc = Jsoup.connect("https://www.oneesports.gg/").get();
            Elements img = doc.select("div.content-wrapper");//changes if failure
            if (!img.isEmpty()) {
                int size=img.size();
                for(int i=0;i<size;i++){

                    String imageurl = img.select("div.image-wrap-16by9").select("img").attr("abs:src");
                    runOnUiThread(() -> {

                        Picasso.get().load(imageurl).into(image2);
                    });
                }


            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }).start();}}




