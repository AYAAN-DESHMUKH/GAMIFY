package com.example.practise;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;

public class homepage extends AppCompatActivity {
    Button feed,contact,searchb,events,comapny;
ImageView news,godofwar,rd2,fifa23,hogwarts,batman;
TextView newslatest;
Button genre;



    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        news=findViewById(R.id.latest);
comapny=findViewById(R.id.comapniesbolte);
rd2=findViewById(R.id.rd2);
batman=findViewById(R.id.bat);
fifa23=findViewById(R.id.fifa23);
hogwarts=findViewById(R.id.harry);
                newslatest=findViewById(R.id.latesttext);
                godofwar=findViewById(R.id.godofwar);
events=findViewById(R.id.newsbolte);
        searchb=findViewById(R.id.gamesearch);
feed=findViewById(R.id.feedback_page);
contact=findViewById(R.id.contact_button);
genre=findViewById(R.id.generation);
comapny.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        startActivity(new Intent(homepage.this,companyinfo.class));
    }
});
        batman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(homepage.this, batman.class));
            }
        });
        rd2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(homepage.this, reddead2.class));
            }
        });
       hogwarts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(homepage.this, hogwartslegacy.class));
            }
        });
        fifa23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(homepage.this, fifa23.class));
            }
        });
godofwar.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        startActivity(new Intent(homepage.this, godofwarragnarok.class));
    }
});
genre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(homepage.this,genre.class));
            }
        });
new newsdisplay().execute();
newsl();
feed.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        startActivity(new Intent(homepage.this, feedback.class));
    }
});
        searchb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                testingpage();

            }

            private void testingpage() {

             startActivity(new Intent(homepage.this,testing.class));
            }
        });
        feed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(homepage.this, feedback.class));
            }
        });

        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(homepage.this, contact_us.class));
            }
        });
        events.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(homepage.this,via_phone.class));
            }
        });
    }



    private class newsdisplay extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            try {

                Document document = Jsoup.connect("https://www.gamespot.com/news/").get();
                Elements search= document.select("div.card-item.base-flexbox.flexbox-align-center.width-100.border-bottom-grayscale--thin");
                int size=search.size();


                for(int i=0;i<size;i++)
                {
                    String text=search.select("div.card-item__content").select("h4").eq(i).text();
                    return text;

                }

            }


            catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {

                newslatest.setText(result);
            } else {

               newslatest.setText("failed to show the information,try using '-' in case of spaces");
            }
        }}


    private void newsl() {
        new Thread(() -> {

            try {
                Document doc = Jsoup.connect("https://www.gamespot.com/news/").get();
                Elements img = doc.select("div.card-item.base-flexbox.flexbox-align-center.width-100.border-bottom-grayscale--thin");//changes if failure
                if (!img.isEmpty()) {
                    int size=img.size();
                    for(int i=0;i<size;i++){

                        String imageurl = img.select("div.card-item__img.overflow--hidden.card-image-overlay.order--one.card-item__img--margin-right").select("img").attr("abs:src");
                        runOnUiThread(() -> {

                            Picasso.get().load(imageurl).into(news);
                        });
                    }


                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }).start();

    }

}










