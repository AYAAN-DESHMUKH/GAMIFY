package com.example.practise;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class gal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gal);
    }
}