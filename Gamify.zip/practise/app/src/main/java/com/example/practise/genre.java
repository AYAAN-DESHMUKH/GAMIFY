package com.example.practise;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.sax.StartElementListener;
import android.view.View;
import android.widget.ImageView;

public class genre extends AppCompatActivity {
ImageView adventure,sports,fps,survival,suoerheroe,battleroyale;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_genre);
        adventure=findViewById(R.id.adventure);
        sports=findViewById(R.id.footbal);
        fps=findViewById(R.id.fps);
        survival=findViewById(R.id.surviva);
        suoerheroe=findViewById(R.id.superheroe);
        battleroyale=findViewById(R.id.battleroyale);
        adventure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(genre.this,adventure.class));
            }
        });
        sports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(genre.this,sports.class));
            }
        });

        fps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(genre.this,fps.class));
            }
        });
        survival.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(genre.this,survival.class));
            }
        });
        suoerheroe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(genre.this,superheroe.class));
            }
        });
        battleroyale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(genre.this,battleroyale.class));
            }
        });
    }
}