package com.example.practise;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class login extends AppCompatActivity {
    TextView linker;
    EditText email;
    EditText password;
    Button login;
    FirebaseAuth authentication;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        linker=findViewById(R.id.linking);
        login=findViewById(R.id.loginbolte);
        email=findViewById(R.id.emailid);
        password=findViewById(R.id.passwordplz);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createuser();


            }

        });


    }

    private void createuser() {
        String mailid=email.getText().toString();
        String pass=password.getText().toString();
        authentication=FirebaseAuth.getInstance();
        authentication.createUserWithEmailAndPassword(mailid,pass).addOnCompleteListener(login.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {

                    Toast.makeText(login.this,"login successfull",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(login.this, homepage.class));
                }




            }
        });



    }
}