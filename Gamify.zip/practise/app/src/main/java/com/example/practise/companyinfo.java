package com.example.practise;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class companyinfo extends AppCompatActivity {
ImageView rockstart,ubisoft,activision,fromsoftware,eagames;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_companyinfo);
        rockstart=findViewById(R.id.torock);
        ubisoft=findViewById(R.id.toubisoft);
        activision=findViewById(R.id.toactive);
        fromsoftware=findViewById(R.id.tofromsoft);
        eagames=findViewById(R.id.toea);
        rockstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(companyinfo.this,rockstargames.class));
            }
        });
        ubisoft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(companyinfo.this,ubisoft.class));
            }
        });
        activision.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(companyinfo.this,activision.class));
            }
        });
        fromsoftware.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(companyinfo.this,fromsoftware.class));
            }
        });
        eagames.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(companyinfo.this,easports.class));
            }
        });
    }
}